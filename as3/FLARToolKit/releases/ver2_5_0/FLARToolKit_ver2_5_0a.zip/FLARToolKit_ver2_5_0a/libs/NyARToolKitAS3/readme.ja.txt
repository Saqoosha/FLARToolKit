ARToolKit ActionScript3 class library NyARToolkit.
Copyright (C)2010 Ryo Iizuka

version 2.5.0

http://nyatla.jp/nyartoolkit/
airmail(at)ebony.plala.or.jp
wm(at)nyatla.jp
--------------------------------------------------




・NyARToolkit/2.5

NyARToolkitAS3は、NyARToolkitのActionScript版です。
NyARToolkit 2.5.0をベースに構築されています。


NyARToolkitAS3は、FLARToolKitへ最新のAPIを供給する目的で実装されています。
単独でも動作しますが、FLARToolKitと組み合わせての利用をお勧めします。
http://www.libspark.org/wiki/saqoosha/FLARToolKit


・ライセンス

NyARToolkitは、商用ライセンスとGPLv3以降のデュアルライセンスを採用しています。


 -GPL
 GPLについては、LICENCE.txtをお読みください。

 -商用ライセンス
 商用ライセンスについては、ARToolWorks社に管理を委託しております。
 http://www.artoolworks.com/Home.html

 日本国内での販売については、下記にお問い合わせ下さい。
 http://www.msoft.co.jp/pressrelease/press090928-1.html




・謝辞

加藤博一先生
http://www.hitl.washington.edu/artoolkit/
ARToolKitを世に送り出してくださいました。有難うございます。

Mr. Mark Billinghurst
ARToolKitを世に送り出してくださいました。NyARToolKit/FLARToolKitの
ライセンス・流通環境整備に協力して頂きました。有難うございます。

Saqooshaさん
FLARToolKitの実装、高速化をして頂きました。有難うございます。