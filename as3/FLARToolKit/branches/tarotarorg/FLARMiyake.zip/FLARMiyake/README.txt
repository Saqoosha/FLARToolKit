Miyake

----------------------------------------------------------------------
 Include External library
----------------------------------------------------------------------
[papervision3d Public Beta 2.0]
 Open Source realtime 3D engine for Flash
 URL     : http://code.google.com/p/papervision3d/
 License : MIT License

FLARToolkit
 Author  : Saqoosha
 URL     : http://www.libspark.org/wiki/saqoosha/FLARToolKit
 License : GNU General Public License